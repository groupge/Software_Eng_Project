<?php
    class EventCategory
    {
        const Art = "ART";
        const Tech = "TECH";
        const Music = "MUSIC";
        const Entertainment = "ENTERTAINMENT";
        const Business = "BUSINESS";
        const OTHERS = "OTHERS";
            
    }
?>

